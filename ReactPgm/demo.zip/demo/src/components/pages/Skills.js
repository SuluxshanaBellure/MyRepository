import "./skills.css";

export default function Skills(){
    return(
        <>
          
<h1>My Skills</h1>

<p>HTML</p>
<div class="container">
  <div class="skills html">90%</div>
</div>

<p>CSS</p>
<div class="container">
  <div class="skills css">80%</div>
</div>

<p>JavaScript</p>
<div class="container">
  <div class="skills js">65%</div>
</div>

<a href="" className="btn">Read More</a>

        </>
    )
}