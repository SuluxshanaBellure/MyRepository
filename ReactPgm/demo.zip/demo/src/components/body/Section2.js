
export default function Section2(){
   
    return(
        <>
         <h2>Section2</h2>
        </>
    )
}